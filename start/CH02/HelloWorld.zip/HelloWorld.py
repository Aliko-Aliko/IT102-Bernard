#!/usr/bin/env python3
# A simple 'Hello world' script in python
# created by Bernard

# Ask the user for their name
name =input('what is your names?')
# print('Hello ' + name'!')

# print a positive message
print('Today is going to be a great day!')

# Ask for age and  calculate future age
age = int(input('How old are you?'))
future_age = age + 2

print(f' In 2 years, you will be {future_age} years old')